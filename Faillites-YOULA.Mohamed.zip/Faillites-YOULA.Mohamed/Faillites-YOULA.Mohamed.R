F<-read.table(file="5year.arff",sep=",",dec=".")#chargement de donn�es
F[F=="?"]<-NA #les valeurs manquantes NA

ff1<-F[1:5500,]#les lignes de F associ�es � la classe "0" 
set.seed(123)
r1 <- sample(610,replace = FALSE)#choix al�atoire des individus
f1<-ff1[r1,]
f2<-F[5501:5910,]#les lignes de F associ�es � la classe "1"

DATA<-rbind(f1,f2)
Y1<-DATA[,1:64]# variable � expliquer
for (i in 1:(ncol(Y1))) {                                              
  Y1[,i] <- as.numeric(as.factor(Y1[,i]))#reconvertion des variables explicatives en numerique
}
Y2<-as.factor(DATA[,65])#convertion de la variable � explicative en variable qualitative 

data1<-data.frame(Y2,Y1)
set.seed(123)
r2 <- sample(nrow(data1),replace = FALSE)#permutation al�atroire de lignes
data<-data1[r2,]#nouvel banque de donn�es � utiliser
data$Y2<-factor(data$Y2, levels = c(0,1), labels = c("class_0","class_1")) #la classe 0 etla classe 1

########################## APPLICATION DE RANDOMFOREST ###########################################

set.seed(123)
library(randomForest)
model.1 <- randomForest( Y2 ~ ., data =data, na.action = na.roughfix)
print(model.1)

########### trouver le nombre d'arbre ##############################

set.seed(123)
model.2<- randomForest(Y2~ ., data = data, ntree = 5000, mtry = 8, na.action = na.roughfix)
print(model.2)

plot(model.2$err.rate[,1], type ="l", xlab = "nombre d'arbres", ylab = "erreur OOB")


#############trouver le nombre de variable ###############################
set.seed(123)
model.3 <- randomForest(Y2~ ., data =data, ntree = 3000, mtry =16, na.action = na.roughfix)
print(model.3)

set.seed(123)
model.4 <- randomForest(Y2~ ., data = data, ntree = 3000, mtry = 4, na.action = na.roughfix)
print(model.4)

##### REPRESENTATION GRAPHIQUE 
varImpPlot(model.3)


library(ggplot2)
p1 <- ggplot(data, aes (V45,V40, colour= factor(Y2)))
p1 + geom_point()

p2 <- ggplot(data, aes (V39,V41, colour= factor(Y2)))
p2 + geom_point()


plot(Y2 ~V39, data = data,col=c("light green","orange"))
plot(Y2 ~V41, data = data,col=c("light green","orange"))




